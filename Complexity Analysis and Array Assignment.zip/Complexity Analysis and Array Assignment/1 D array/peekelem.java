
public class peekelem {

    public static void main(String[] args) {
        int[] array = new int[]{1,3,2,6,5};

        System.out.println(nPeaks(array, 2));
    }

    static int nPeaks(int[] array, int range) {

        if (array == null) {
            return 0;
        }

        int result = 0, l, r;

        for (int i = 0; i < array.length; i++) {
            boolean isPeak = true;
            l = Math.max(0, i - range);
            r = Math.min(array.length - 1, i + range);
            for (int j = l; j <= r; j++) {
                if (i == j) {
                    continue;
                }
                if (array[i] < array[j]) {
                    isPeak = false;
                    break;
                }
            }

            if (isPeak) {
                System.out.println("Peak element is "+array[i]);
                result++;
                i += range;
            }
        }

        return result;
    }
}