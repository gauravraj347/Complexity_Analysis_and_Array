

public class evemelem {

    public static void main(String[] args) {
        
        int arr[]={34,21,54,65,43};
        int arry[] = {4,3,6,7,1};
        for(int elem:arr){
            if(elem%2==0){
                System.out.println(elem);
            }

        }
        System.out.println();
        for(int elemt:arry){
            if(elemt%2==0){
                System.out.println(elemt);
            }
        }
        
    }
}