/**
 * evensum
 */
public class evensum {

    public static void main(String[] args) {
        int arry[]={3,20,4,6,9};
        int i = 0, sum = 0;
        while (i < arry.length) {
            sum += arry[i];
            i += 2;

        }
        System.out.println(sum);
    }
}